import {Model} from './Model.js';

export class Controller {
    //Load all the data
    constructor(model, view) {
        this.model = model;
        this.view = view;
        //Spinner from class.
        this.view.renderSpinner();

        //Get data from 'about' page.
        let response = this.model.getData('/about');
        
        //When loaded, send the data to the function in View.
        response.done((data) => {
            this.view.renderAboutSection(data);
            
        });
        //Get data from 'people' page.
        response = this.model.getData('/people');
        //When loaded, send the data to the function in View.
        response.done((data) => {
            this.view.renderPeopleSection(data);
            
        });
        //Get data from 'degrees' page.
        response = this.model.getData('/degrees');
        //When loaded, send the data to the function in View.
        response.done((data) => {
            this.view.renderDegreeSection(data);
            
        });
        //Get data from 'minors' page.
        response = this.model.getData('/minors');
        //When loaded, send the data to the function in View.
        response.done((data) => {
            this.view.renderMinorsSection(data);
            
        });
        //Get data from 'employment' page.
        response = this.model.getData('/employment');
        
        //When loaded, send the data to the 2 functions in View.
        response.done((data) => {
            this.view.renderEmploymentSection(data);
            this.view.renderTablesSection(data);
        });
        
        
    }
}