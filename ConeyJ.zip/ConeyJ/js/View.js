export class View {
    
    constructor() {
        //Variables.
        this.$aboutSection = $('#section-about');
        this.$peopleSection = $('#section-people');
        this.$degreeSection = $('#section-degrees');
        this.$minorsSection = $('#section-minors');
        this.$employmentSection = $('#section-employment');
        this.$tablesSection = $('#section-tables');
    }
    //Load the spinner
    renderSpinner() {
        this.$aboutSection.html('<img src="media/gears.gif" id="spinner"/>');
        
    }
    //Renders 'about' section. Gets data from Controller, like all other methods.
    renderAboutSection(data) {
        this.$aboutSection.html(''); //removes any previous content (like spinner)
        //Create div for info.
        let $aboutDiv = $('<div id="about"></div>');
        //Format the header and main paragraph of page.
        let $aboutItem = $(`<h2 class="header">${data.title}</h2><p class="centerParagraph">${data.description}</p><p class="centerParagraph">${data.quote}</p><p class="centerParagraph">${data.quoteAuthor}</p>`);
        //Append them to the div.    
        $aboutDiv.append($aboutItem);
        //Display the info.
        this.$aboutSection.append($aboutDiv);
    }
    //Renders 'people' section.
    renderPeopleSection(data) {
        this.$peopleSection.html(''); //removes any previous content (like spinner)
        //Create div for content.
        let $peopleDiv = $('<div id="people"></div>');
        
        //Create people section title.
        let $peopleItem = $(`<h2 class="header">${data.title}</h2><p class="centerParagraph">${data.subTitle}</p>`);
            $peopleDiv.append($peopleItem);
        //Create list.
        let $peopleList = $(`<ul class="peopleList"></ul>`);
        //Loop through data and add to list.
        $.each(data.faculty, (index, item) => {
            let $peopleItem = $(`<li class="person"><div class="card"><div class="front"><p class="personName">${item.name}</p><p class="personTitle">${item.title}</p></div><div class="back"><img src="https://ist.rit.edu/assets/img/people/${item.username}.jpg" class="personImg"/></div></div></li>`);
            
            $peopleList.append($peopleItem);
        });
        $peopleDiv.append($peopleList);
        //Display the info.
        this.$peopleSection.append($peopleDiv);
        //Flips the cards on hover.
        $(".card").flip({
            axis: 'x',
            trigger: 'hover'
        });
    }
    //Renders 'degree' section.
    renderDegreeSection(data) {

        this.$degreeSection.html(''); //removes any previous content (like spinner)
        //Create div for content.
        let $degreeDiv = $('<div id="degree"></div>');
        let $degreeItem = $(`<h2 class="header">Undergraduate Degrees</h2>`);
        //Create list to hold data.
        let $degreeBit = $(`<div></div>`);
        
        $degreeDiv.append($degreeItem);
        
        let $degreeList = $('<ul class="degreeList"></ul>');
        //Loop through data and add to list.
        $.each(data.undergraduate, (index, item) => {
            let $degreeItem = $(`<li class="degreeItem"><p class="degreeTitle">${item.title}</p><p>${item.description}</p></li>`);
            $degreeList.append($degreeItem);
        });
        $degreeBit.append($degreeList);
        $degreeDiv.append($degreeBit);
        
        
        $degreeItem = $(`<h2 class="header" id="gradHeader">Graduate Degrees</h2>`);
        
        $degreeBit = $(`<div></div>`);
        
        $degreeDiv.append($degreeItem);
        
        $degreeList = $('<ul class="degreeList" id="gradList"></ul>');
        //Iterate through and create the list of div data.
        $.each(data.graduate, (index, item) => {
            //Sort out bad data.
            if (typeof item.description !== "undefined"){
                let $degreeItem = $(`<li class="degreeItem"><p class="degreeTitle">${item.title}</p><p>${item.description}</p></li>`);
                $degreeList.append($degreeItem);
            }else{
                let $degreeItem = $(`<li class="degreeItem" id="certSection"><p class="degreeTitle" id="certTitle">Graduate Advanced Certificates</p></li>`);
                $.each(item.availableCertificates, (index, option) => {
                    let $degreeCertificates = $(`<p class="degreeTitle">${option}</p>`);
                    $degreeItem.append($degreeCertificates);
                });
                $degreeList.append($degreeItem);
            }
        });
        $degreeBit.append($degreeList);
        $degreeDiv.append($degreeBit);
        //Display the info.
        this.$degreeSection.append($degreeDiv);
    }
    //Renders 'minors' section.
    renderMinorsSection(data) {
        this.$minorsSection.html(''); //removes any previous content (like spinner)
        //Create div for content.
        let $minorsDiv = $(`<div id="minors"></div>`);
        
        let $minorsItem = $(`<h2 class="header">Undergraduate Minors</h2>`);
        let $minorsBit = $(`<div></div>`);
        
        $minorsDiv.append($minorsItem);
        
        let $minorsList = $(`<ul class="minorsList"></ul>`);
                
        $.each(data.UgMinors, (index, item) => {
            if (item.title !== "Health IT (MEDINFO-MN)"){
                let $minorsItem = $(`<li class="minorsItem"><p>${item.title}</p></li>`);
                $minorsList.append($minorsItem);
            }
        });
        //Add to rest of the loaded code.
        $minorsBit.append($minorsList);
        $minorsDiv.append($minorsBit);
        //Display the info.
        this.$minorsSection.append($minorsDiv);
    }
    //Renders 'employment' section.
    renderEmploymentSection(data) {
        this.$employmentSection.html(''); //removes any previous content (like spinner)
        //Create div for content.
        let $employmentDiv = $('<div id="employment"></div>');
        
        
        let $employmentItem = $(`<h2 class="header">${data.introduction.title}</h2>`);
            $employmentDiv.append($employmentItem);
        
        $.each(data.introduction.content, (index, item) => {
                let $employmentItem = $(`<p class="sectionHeader">${item.title}</p><p class="centerParagraph">${item.description}</p>`);
                $employmentDiv.append($employmentItem);
                if (item.title === "Employment"){
                    let $employmentList = $(`<ul class="employmentStats"></ul>`);
                    $.each(data.degreeStatistics.statistics, (index, item) => {
                        let $employmentItem = $(`<li class="employmentItem"><p class="employmentSubtitle">${item.value}</p><p class="employmentDesc">${item.description}</p></li>`);
                        $employmentList.append($employmentItem);
                    });
                    $employmentDiv.append($employmentList);
                }
        });
        
        $employmentItem = $(`<p class="subtitle">${data.employers.title}</p>`);
        $employmentDiv.append($employmentItem);
        
        let $employmentList = $(`<ul class="employers"></ul>`);
        $.each(data.employers.employerNames, (index, item) => {
                let $employmentItem = $(`<li class="employersItem"><p>${item}</p> </li>`);
                $employmentList.append($employmentItem);
        });
        $employmentDiv.append($employmentList);
        
        $employmentItem = $(`<p class="subtitle">${data.careers.title}</p>`);
        $employmentDiv.append($employmentItem);
        
        
        $employmentList = $(`<ul class="employers"></ul>`);
        $.each(data.careers.careerNames, (index, item) => {
                let $employmentItem = $(`<li class="employersItem"><p>${item}</p> </li>`);
                $employmentList.append($employmentItem);
        });
        //Add to rest of the loaded code.
        $employmentDiv.append($employmentList);
        //Display the info.
        this.$employmentSection.append($employmentDiv);
    }
    //Renders 'tables' section.
    renderTablesSection(data) {
        this.$tablesSection.html(''); //removes any previous content (like spinner)
        //Format the table display buttons..
        let $tablesDiv = $(`<div id="tables"><div class="table" id="employmentTable"><p class="tableText">Employment Table</p></div><div class="table" id="coopTable"><p class="tableText">Co-op Table</p></div></div>`);
        //Format the dataTable headers.
        let $tableTables = $(`<table id="employTable" class="display"><thead><tr><th>Employer</th><th>Degree</th><th>City</th></tr></thead></table>`);
        //Format dataTable body.
        let $tableBody = $(`<tbody></tbody>`);
        
        //Iterate through data to insert into the tables.
        $.each(data.employmentTable.professionalEmploymentInformation, (index, item) => {
            let $tableItem = $(`<tr><td>${item.employer}</td><td>${item.degree}</td><td>${item.city}</td></tr>`);
            //Add to body section.
            $tableBody.append($tableItem);
        });
        //Add to rest of the loaded table code.
        $tableTables.append($tableBody);
        
        //Display the info, freeing up all the variables.
        this.$tablesSection.append($tablesDiv);
        this.$tablesSection.append($tableTables);
        
        $tableTables = $(`<table id="cTable" class="display"><thead><tr><th>Employer</th><th>Degree</th><th>City</th></tr></thead></table>`);
        $tableBody = $(`<tbody></tbody>`);
        
        $.each(data.coopTable.coopInformation, (index, item) => {
            let $tableItem = $(`<tr><td>${item.employer}</td><td>${item.degree}</td><td>${item.city}</td></tr>`);
            $tableBody.append($tableItem);
        });
        $tableTables.append($tableBody);
        
        this.$tablesSection.append($tableTables);
        
        //Set up the dataTables when loaded.
        $(document).ready( function () {
            $('#employTable').DataTable();
        } );
        
        $(document).ready( function () {
            $('#cTable').DataTable();
        } );
        
        //Toggle the datatables on button click.
        $( "#employmentTable" ).click(function() {
            $( "#employTable" ).toggle();
        });
        
        $( "#coopTable" ).click(function() {
            $( "#cTable" ).toggle();
        });
        
    }
    
}
