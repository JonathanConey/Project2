import java.util.*;

public class Recipe extends Food {
    private final ArrayList<BasicFood> ingredients;

    String newName;

    public Recipe(String name, ArrayList<BasicFood> _ingredients) {
        super(name, calculateCalories(_ingredients), calculateFat(_ingredients), calculateCarbs(_ingredients), calculateProtein(_ingredients));
        newName = name;
        ingredients = _ingredients;
    }

    private static double calculateCalories(ArrayList<BasicFood> ingredients) {
        double calories = 0;
        for (Food ingredient : ingredients) {
            calories += ingredient.getCalories();
        }
        return calories;
    }

    private static double calculateFat(ArrayList<BasicFood> ingredients) {
        double fat = 0;
        for (Food ingredient : ingredients) {
            fat += ingredient.getFat();
        }
        return fat;
    }

    private static double calculateCarbs(ArrayList<BasicFood> ingredients) {
        double carbs = 0;
        for (Food ingredient : ingredients) {
            carbs += ingredient.getCarbs();
        }
        return carbs;
    }

    private static double calculateProtein(ArrayList<BasicFood> ingredients) {
        double protein = 0;
        for (Food ingredient : ingredients) {
            protein += ingredient.getProtein();
        }
        return protein;
    }

    @Override
    public String toString() {
        String str = "r," + newName;
        for (Food ingredient : ingredients) {
            str = str + "," + ingredient.getName() + ",";
        }
        str = str.substring(0,str.length() - 1);
        return str;
    }
}
