public class WeightLog {
    private final String year;
    private final String month;
    private final String day;
    private double weight;
    //Used to get Weight data from log.csv file.
    public WeightLog(){
      year = "";
      month = "";
      day = "";
    }
    
    public WeightLog(String _year, String _month, String _day, double _weight) {
        year = _year;
        month = _month;
        day = _day;
        weight = _weight;

    }

    public String getYear() {
        return year;
    }

    public String getMonth() {
        return month;
    }

    public String getDay() {
        return day;
    }

    public double getWeight() {
        if (weight == 0){
            weight = 150;
        }
        return weight;
    }

    public void setWeight(double _weight){
        weight = _weight;
    }

    @Override
    public String toString() {
        return String.format("%s,%s,%s,w,%.1f", getYear(), getMonth(), getDay(), getWeight());
    }
}