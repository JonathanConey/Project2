public class CalorieLog {
    private final String year;
    private final String month;
    private final String day;
    private double calories;
   //Use to retrieve Calorie data from log.csv file.
    public CalorieLog(){
      year = "";
      month = "";
      day = "";
    }
    
    public CalorieLog(String _year, String _month, String _day, double _calories) {
        year = _year;
        month = _month;
        day = _day;
        calories = _calories;

    }

    public String getYear() {
        return year;
    }

    public String getMonth() {
        return month;
    }

    public String getDay() {
        return day;
    }

    public double getCalories() {
        if (calories == 0){
            calories = 2000;
        }
        return calories;
    }

    public void setCalories(double _calories){
        calories = _calories;
    }



    @Override
    public String toString() {
        return String.format("%s,%s,%s,c,%.1f", getYear(), getMonth(), getDay(), getCalories());
    }
}