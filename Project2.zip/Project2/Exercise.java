public abstract class Exercise {
    private final String name;
    private final double calories;

    public Exercise(String _name, double _calories) {
        name = _name;
        calories = _calories;
    }

    public String getName() {
        return name;
    }

    public double getCalories() {
        return calories;
    }
}