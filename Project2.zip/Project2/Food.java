public abstract class Food {
    private final String name;
    private final double calories;
    private final double fat;
    private final double carbs;
    private final double protein;

    public Food(String _name, double _calories, double _fat, double _carbs, double _protein) {
        name = _name;
        calories = _calories;
        fat = _fat;
        carbs = _carbs;
        protein = _protein;
    }

    public String getName() {
        return name;
    }

    public double getCalories() {
        return calories;
    }

    public double getFat() {
        return fat;
    }

    public double getCarbs() {
        return carbs;
    }

    public double getProtein() {
        return protein;
    }
    
}