//Exactly like BasicFood, but extends Exercise.
public class BasicExercise extends Exercise {
    public BasicExercise(String name, double calories) {
        super(name, calories);
    }

    @Override
    public String toString() {
        return String.format("e,%s,%.1f", getName(), getCalories());
    }
}