import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class DailyLog {
   //Objects of each data type
    public WeightLog weightLog;
    public CalorieLog calorieLog;
    public FoodLog foodLog;
    public ExerciseLog exerciseLog;
   //File constant
    private final File FILE = new File("log.csv");
   //Initialize attributes
    public DailyLog() {
        weightLog = new WeightLog();
        calorieLog = new CalorieLog();
        foodLog = new FoodLog();
        exerciseLog = new ExerciseLog();
    }
    //Loads Weight object from log.csv
    public void loadWeight(String _day,String _month,String _year){
      try {
            //Iterate through file
            Scanner scanner = new Scanner(FILE);
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                //Split line by comma
                String[] ary = line.split(",");
                //Check if month matches up.
                if(ary[0] == _year && ary[1] == _month && ary[2] == _day){
                  //Probably outdated, but didn't want to risk it.
                   if (ary.length > 0) {
                     //Check index 3 if is letter 'w', if so then this is a weight entry.
                       String type = ary[3];
                       if (type.equals("w")) {
                           //Set the weightLog object as this entry
                           weightLog.setWeight(Double.parseDouble(ary[4]));
                           //Save
                           saveWeight();
                        }
                     }
                  }
            }
            scanner.close();
        } catch (IOException e) {
            System.out.println("An error occurred while loading the log file.");
            e.printStackTrace();
        }
    }
    //Same as weight but for calories
    public void loadCalories(String _day,String _month,String _year){
      try {
            Scanner scanner = new Scanner(FILE);
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] ary = line.split(",");
                if(ary[0] == _year && ary[1] == _month && ary[2] == _day){
                   if (ary.length > 0) {
                       String type = ary[3];
                       if (type.equals("c")) {
                           calorieLog.setCalories(Double.parseDouble(ary[4]));
                           saveCalories();
                        }
                     }
                  }
            }
            scanner.close();
        } catch (IOException e) {
            System.out.println("An error occurred while loading the log file.");
            e.printStackTrace();
        }
    }
    //Same as weight but for food
    public void loadFood(String _day,String _month,String _year){
      try {
            Scanner scanner = new Scanner(FILE);
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] ary = line.split(",");
                if(ary[0] == _year && ary[1] == _month && ary[2] == _day){
                   if (ary.length > 0) {
                       String type = ary[3];
                       if (type.equals("f")) {
                           //Get data from line and set the food
                           String foodName = ary[4];
                           double count = Double.parseDouble(ary[5]);
                           foodLog.setFood(foodName, count);
                           saveFood();
                       }
                   }
                }
            }
            scanner.close();
        } catch (IOException e) {
            System.out.println("An error occurred while loading the log file.");
            e.printStackTrace();
        }
    }
    //Same as weight but for Exercise
    public void loadExercise(String _day,String _month,String _year){
      try {
            Scanner scanner = new Scanner(FILE);
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] ary = line.split(",");
                if(ary[0] == _year && ary[1] == _month && ary[2] == _day){
                   if (ary.length > 0) {
                       String type = ary[3];
                       if (type.equals("e")) {
                           String exerciseName = ary[4];
                           double count = Double.parseDouble(ary[5]);
                           exerciseLog.setExercise(exerciseName, count);
                           saveExercise();
                       }
                   }
                }
            }
            scanner.close();
        } catch (IOException e) {
            System.out.println("An error occurred while loading the log file.");
            e.printStackTrace();
        }
    }
    //Write the weight object to file.
    public void saveWeight(){
      try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE,true));
            oos.writeObject(weightLog);
            oos.close();
        } catch (IOException e) {
            System.out.println("An error occurred while saving the log file.");
            e.printStackTrace();
        }
    }
    //Write calories
    public void saveCalories(){
      try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE,true));
            oos.writeObject(calorieLog);
            oos.close();
        } catch (IOException e) {
            System.out.println("An error occurred while saving the log file.");
            e.printStackTrace();
        }
    }
    //Write food
    public void saveFood(){
      try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE,true));
            oos.writeObject(foodLog);
            oos.close();
        } catch (IOException e) {
            System.out.println("An error occurred while saving the log file.");
            e.printStackTrace();
        }
    }
    //Write exercise
    public void saveExercise(){
      try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE,true));
            oos.writeObject(exerciseLog);
            oos.close();
        } catch (IOException e) {
            System.out.println("An error occurred while saving the log file.");
            e.printStackTrace();
        }
    }

   //Setters and getters.
    public double getWeight() {
        return weightLog.getWeight();
    }

    public void setWeight(double weight) {
        weightLog.setWeight(weight);
    }

    public double getCalories() {
        return calorieLog.getCalories();
    }

    public void setCalories(double calorieLimit) {
        calorieLog.setCalories(calorieLimit);
    }

    public Map<String, Double> getFood() {
        return foodLog.getFood();
    }

    public void setFood(String foodName, double servings) {
        foodLog.setFood(foodName, servings);
    }
    
    public Map<String, Double> getExercise() {
        return exerciseLog.getExercise();
    }

    public void setExercise(String name, double calories) {
        exerciseLog.setExercise(name, calories);
    }
}
