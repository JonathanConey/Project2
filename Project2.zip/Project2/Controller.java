import java.util.*;
import java.text.*;

import java.io.*;

public class Controller{
   String year;
   String month;
   String day;
   
   String calorieLimit;
   String weightLimit;
   
   DailyLog dailyLog = new DailyLog();
   
   View view;
   //Assign current View to variable.
   public Controller(View _view){
      view = _view;
   }
   
   //Add Recipe
   public void addRecipe(String recipe){
      //Split recipe String into Array by spaces.
      String[] recipeArray = recipe.split(" ");
      //Iterate through array.
      for(int i = 0;i < recipeArray.length;i++){
         //If not first item.
         if(i > 0){
            //If in number position.
            if(i % 2 == 0){
               //Check if float.
               try{
                  float floatTest = Float.parseFloat(recipeArray[i]);
                  
               }catch(Exception e){
                  System.out.println("Wrong format");
                  return;
               }
            }
            //If in String position.
            else if(i % 2 == 1){
               //Check if float.
               try{
                  float floatTest = Float.parseFloat(recipeArray[i]);
                  System.out.println("Wrong format");
                  return;
               }catch(Exception e){}
            }
         }
         //If first item.
         else{
            //Check if float.
            try{
                  float floatTest = Float.parseFloat(recipeArray[i]);
                  System.out.println("Wrong format");
                  return;
               }catch(Exception e){}
         }
      }
      //Create ArrayList for BasicFoods
      ArrayList<BasicFood> foods = new ArrayList<>();
      try{
         //Iterate through recipeArray, skipping the first item.
         for(int i = 1;i < recipeArray.length;i++){
            //If the index is odd (meaning that it should be a food item):
            if(i % 2 == 1){
               //Search the file for the food item, and assign split string to array.
               String[] lineArray = loadFood(recipeArray[i]);
               //Make sure that loadFood succeeded.
               if(lineArray[0] != "Failed"){
                  BasicFood loadedFood;
                  //Create new food item and add to food list.
                  loadedFood = new BasicFood(lineArray[1],Float.parseFloat(lineArray[2]),Float.parseFloat(lineArray[3]),Float.parseFloat(lineArray[4]),Float.parseFloat(lineArray[5]));
                  foods.add(loadedFood);
               }
            }
         }
         //Create recipe and save it.
         Recipe newRecipe = new Recipe(recipeArray[0],foods);
         saveRecipe(newRecipe);
      }catch(IOException ioe){}
   };
   
   public void addFood(String food){
      //Split food into array by spaces.
      String[] foodArray = food.split(" ");
      //Check number of fields, else stop.
      if (foodArray.length == 5){
         //Test if first item in array is float, if it is then stop, else keep going.
         try{
            float floatTest = Float.parseFloat(foodArray[0]);
            System.out.println("Wrong format");
            return;
         //Iterate through rest of array. If array is float, then keep going, else stop.
         }catch(Exception e){
            //Iterate through food array except for first item.
            for(int i = 1;i < foodArray.length;i++){
               try{
                  //Check if it is a float. If not, break.
                  float floatTest = Float.parseFloat(foodArray[i]);
               }catch(Exception ex){
                  System.out.println("Wrong format");
                  return;
               }
            }
            //Create and save the food.
            BasicFood newFood = new BasicFood(foodArray[0],Float.parseFloat(foodArray[1]),Float.parseFloat(foodArray[2]),Float.parseFloat(foodArray[3]),Float.parseFloat(foodArray[4]));
            try{
               saveFood(newFood);
            }catch(IOException ioe){}
         }
      }else{
         System.out.println("Invalid recipe.");
      }
   };
   
   public void addExercise(String exercise){
      //Split food into array by spaces.
      String[] exerciseArray = exercise.split(" ");
      //Check number of fields, else stop.
      if (exerciseArray.length == 5){
         //Test if first item in array is float, if it is then stop, else keep going.
         try{
            float floatTest = Float.parseFloat(exerciseArray[0]);
            System.out.println("Wrong format");
            return;
         //Iterate through rest of array. If array is float, then keep going, else stop.
         }catch(Exception e){
            //Iterate through food array except for first item.
            for(int i = 1;i < exerciseArray.length;i++){
               try{
                  //Check if it is a float. If not, break.
                  float floatTest = Float.parseFloat(exerciseArray[i]);
               }catch(Exception ex){
                  System.out.println("Wrong format");
                  return;
               }
            }
            //Create and save the exercise.
            BasicExercise newExer = new BasicExercise(exerciseArray[0],Float.parseFloat(exerciseArray[1]));
            try{
               saveExercise(newExer);
            }catch(IOException ioe){}
         }
      }else{
         System.out.println("Invalid recipe.");
      }
   };
   //No work, it is very similar to the createRecipe, but it just formats a string.
   public void removeRecipe(String recipe){
      //Split recipe String into Array by spaces.
      String[] recipeArray = recipe.split(" ");
      //Iterate through array.
      for(int i = 0;i < recipeArray.length;i++){
         //If not first item.
         if(i > 0){
            //If in number position.
            if(i % 2 == 0){
               //Check if float.
               try{
                  float floatTest = Float.parseFloat(recipeArray[i]);
                  
               }catch(Exception e){
                  System.out.println("Wrong format");
                  return;
               }
            }
            //If in String position.
            else if(i % 2 == 1){
               //Check if float.
               try{
                  float floatTest = Float.parseFloat(recipeArray[i]);
                  System.out.println("Wrong format");
                  return;
               }catch(Exception e){}
            }
         }
         //If first item.
         else{
            //Check if float.
            try{
                  float floatTest = Float.parseFloat(recipeArray[i]);
                  System.out.println("Wrong format");
                  return;
               }catch(Exception e){}
         }
      }
      String formattedRecipe = "r,";
      for(String i : recipeArray){
         formattedRecipe += i + ",";
      }
      formattedRecipe = formattedRecipe.substring(0,formattedRecipe.length() - 1);
   };
   //No work, it is very similar to the createFood, but it just formats a string.
   public void removeFood(String food){
      //Split food into array by spaces.
      String[] foodArray = food.split(" ");
      //Check number of fields, else stop.
      if (foodArray.length == 5){
         //Test if first item in array is float, if it is then stop, else keep going.
         try{
            float floatTest = Float.parseFloat(foodArray[0]);
            System.out.println("Wrong format");
            return;
         //Iterate through rest of array. If array is float, then keep going, else stop.
         }catch(Exception e){
            for(int i = 1;i < foodArray.length;i++){
               try{
                  float floatTest = Float.parseFloat(foodArray[i]);
               }catch(Exception ex){
                  System.out.println("Wrong format");
                  return;
               }
            }
            //Add 'b' to start of array.
            String formattedFood = "b,";
            //Create String with comma seperation from array.
            for(String i : foodArray){
               formattedFood += i + ",";
            }
            //Remove the last comma.
            formattedFood = formattedFood.substring(0,formattedFood.length() - 1);
         }
      }else{
         System.out.println("Invalid recipe.");
      }
   };
   
   public void removeExercise(String exercise){
      //Split recipe String into Array by spaces.
      String[] exerciseArray = exercise.split(" ");
      //Iterate through array.
      for(int i = 0;i < exerciseArray.length;i++){
         //If not first item.
         if(i > 0){
            //If in name position.
            if(i == 1){
               //Check if float.
               try{
                  float floatTest = Float.parseFloat(exerciseArray[i]);
                  System.out.println("Wrong format");
                  return;
               }catch(Exception e){}
            }
            //If in calorie burn position.
            else if(i == 2){
               //Check if float.
               try{
                  float floatTest = Float.parseFloat(exerciseArray[i]);
                  
               }catch(Exception e){
                  System.out.println("Wrong format");
                  return;
               }
            }
         }
         //If first item.
         else{
            //Check if float.
            try{
                  float floatTest = Float.parseFloat(exerciseArray[i]);
                  System.out.println("Wrong format");
                  return;
               }catch(Exception e){}
         }
      }
      String formattedRecipe = "e,";
      for(String i : exerciseArray){
         formattedRecipe += i + ",";
      }
      formattedRecipe = formattedRecipe.substring(0,formattedRecipe.length() - 1);
   };
   
   public void submit(String _date,String _calorie,String _weight,String _food,String _exercise){
      //https://www.baeldung.com/java-string-valid-date
      //Validates date.
      DateFormat expectedFormat = new SimpleDateFormat("MM/dd/yyyy");
      expectedFormat.setLenient(false);
      try {
          expectedFormat.parse(_date);
          year = _date.substring(6);
          month = _date.substring(0,2);
          day = _date.substring(3,5);
      } catch (ParseException e) {}
     //Format and prepare the calories for output.
      try{
         //Validate that _calorie is a float
         float floatTest = Float.parseFloat(_calorie);
         //load the calories for this date from log.csv
         dailyLog.loadCalories(day,month,year);
         //Assign attributes to variables
         double consumed = dailyLog.calorieLog.getCalories();
         double expended = dailyLog.exerciseLog.getCalories();
         double net = consumed + expended;
         String limit;
         //Check if exceeds limit.
         if(net > floatTest){
            limit = "Exceeds Calorie Limit";
         }
         else{
            limit = "Within Calorie Limit";
         }
         //Send to log output screen.
         logOutput(String.format("Calories Consumed: %.1f\nCalories Expended: %.1f\nNet Calories: %.1f\n%s",consumed,expended,net,limit));
      }catch(Exception ex){System.out.println(ex);}
         //Same as calories except for weight.
      try{
         float floatTest = Float.parseFloat(_weight);
         dailyLog.loadWeight(day,month,year);
         double dailyWeight = dailyLog.weightLog.getWeight();
         String limit;
         if(dailyWeight > floatTest){
            limit = "Exceeds Weight Limit";
         }
         else{
            limit = "Within Weight Limit";
         }
         logOutput(String.format("Weight Gained: %.1f\n%s",dailyWeight,limit));
      }catch(Exception ex){System.out.println(ex);}
         
         //Validate that food is NOT float
      try{
         float floatTest = Float.parseFloat(_food);
         
      }catch(Exception ex){
         //Assign attributes to variables
         System.out.println(ex);
         dailyLog.loadFood(day,month,year);
         String name = dailyLog.foodLog.getName();
         Double count = dailyLog.foodLog.getServings();
         //Log
         logOutput(String.format("%s Count: %.1f\n",name,count));
      }
      
      //Same as food, but for exercise.
      try{
         float floatTest = Float.parseFloat(_exercise);
         
      }catch(Exception ex){
         System.out.println(ex);
         dailyLog.loadExercise(day,month,year);
         String name = dailyLog.exerciseLog.getName();
         Double count = dailyLog.exerciseLog.getCalories();
         logOutput(String.format("%s Calories: %.1f\n",name,count));
      }
   }
   //Write input to file.
   public static void saveFood(BasicFood _food) throws IOException {
      File file = new File("foods.csv");
      FileWriter writer = null;
        
      writer = new FileWriter(file,true);
      writer.append(_food + "\n");

      writer.flush();
      writer.close();
   }
   //Save exercise to file.
   public static void saveExercise(BasicExercise _exer) throws IOException {
      File file = new File("exercise.csv");
      FileWriter writer = null;
        
      writer = new FileWriter(file,true);
      writer.append(_exer + "\n");

      writer.flush();
      writer.close();
   }
   //Write input to file.
   public static void saveRecipe(Recipe _recipe) throws IOException {
      File file = new File("foods.csv");
      FileWriter writer = null;
        
      writer = new FileWriter(file,true);
      writer.append(_recipe + "\n");

      writer.flush();
      writer.close();
   }
   
   public static String[] loadFood(String _foodName) throws IOException{
      File file = new File("foods.csv");
      Scanner scanner = new Scanner(file);
      //Look through document until find "b", then check if right food. If so, add to array.
      int lineNumber = 1;
      while(scanner.hasNextLine()){
            String line = scanner.nextLine();
            if(line.charAt(0) == 'b'){
               String[] lineArray = line.split(",");
               if(lineArray[1].equals(_foodName)){
                  return lineArray;
                  
               }
            }
            lineNumber++;
      }
      //If the food was not found:
      String[] failArray = {"Failed"};
      return failArray;
   }
    
   public void logOutput(String _output){
      //Write to output field.
      view.outputField.setText(_output);
   }   
}