public class BasicFood extends Food {
    public BasicFood(String name, double calories, double fat, double carbs, double protein) {
        super(name, calories, fat, carbs, protein);
    }

    @Override
    public String toString() {
        return String.format("b,%s,%.1f,%.1f,%.1f,%.1f", getName(), getCalories(), getFat(), getCarbs(), getProtein());
    }
}