import java.util.Map;
import java.util.TreeMap;
//Use to retrieve Food data from log.csv file.
public class FoodLog {
    private final String year;
    private final String month;
    private final String day;
    private String name;
    private double servings;

    private TreeMap<String,Double> map = new TreeMap<>();
    
    public FoodLog(){
      year = "";
      month = "";
      day = "";
      name = "";
      servings = 0;
    }
    
    public FoodLog(String _year, String _month, String _day, String _name, double _servings) {
        year = _year;
        month = _month;
        day = _day;
        name = _name;
        servings = _servings;

    }

    public String getYear() {
        return year;
    }

    public String getMonth() {
        return month;
    }

    public String getDay() {
        return day;
    }

    public String getName(){
        return name;
    }

    public double getServings() {
        return servings;
    }

    public Map<String, Double> getFood(){
        map.put(name, servings);
        return map;
    }

    public void setFood(String _name, double _servings){
        name = _name;
        servings = _servings;
    }

    @Override
    public String toString() {
        return String.format("%s,%s,%s,f,%s, %.1f", getYear(), getMonth(), getDay(), getName(), getServings());
    }
}