import java.util.Map;
import java.util.TreeMap;
//Use to retrieve Exercise data from log.csv file.
public class ExerciseLog {
    private final String year;
    private final String month;
    private final String day;
    private String name;
    private double calories;

    private TreeMap<String,Double> map = new TreeMap<>();
    
    public ExerciseLog(){
      year = "";
      month = "";
      day = "";
      name = "";
      calories = 0;
    }
    
    public ExerciseLog(String _year, String _month, String _day, String _name, double _calories) {
        year = _year;
        month = _month;
        day = _day;
        name = _name;
        calories = _calories;

    }

    public String getYear() {
        return year;
    }

    public String getMonth() {
        return month;
    }

    public String getDay() {
        return day;
    }

    public String getName(){
        return name;
    }

    public double getCalories() {
        return calories;
    }

    public Map<String, Double> getExercise(){
        map.put(name, calories);
        return map;
    }

    public void setExercise(String _name, double _calories){
        name = _name;
        calories = _calories;
    }

    @Override
    public String toString() {
        return String.format("%s,%s,%s,f,%s, %.1f", getYear(), getMonth(), getDay(), getName(), getCalories());
    }
}